import { useState } from 'react';

export interface FieldConfig {
  label: string;
  field: string;
  type?: 'text' | 'number' | 'select' | 'textarea';
  options?: string[];
  disabled?: boolean;
  checkbox?: boolean;
  colSpan?: number;
  children?: FieldConfig[];
  showWhen?: string;
}

export interface SectionConfig {
  title: string;
  color: string;
  borderColor: string;
  fields: FieldConfig[];
  hasPhotos?: boolean;
  hasFiles?: boolean;
  layout?: 'grid' | 'list';
  gridCols?: number;
}

export interface JobEditModalConfig {
  sections: SectionConfig[];
  sectionNames: string[];
}

interface JobEditModalProps {
  config: JobEditModalConfig;
  editData: Record<string, any>;
  onUpdateField: (field: string, value: any) => void;
  onSave: () => void;
  onClose: () => void;
  saving?: boolean;
  dark?: boolean;
  titleField?: string;
  disabledLabel?: string;
}

export default function JobEditModal({
  config,
  editData,
  onUpdateField,
  onSave,
  onClose,
  saving = false,
  dark = true,
  titleField = 'jobNumber',
  disabledLabel = 'read-only',
}: JobEditModalProps) {
  const [newFilePath, setNewFilePath] = useState('');
  const [newFileSection, setNewFileSection] = useState(config.sectionNames[0] || 'General');
  const [newPhotoSection, setNewPhotoSection] = useState(config.sectionNames[0] || 'General');
  const [viewPhoto, setViewPhoto] = useState<any>(null);

  const card = dark ? 'bg-gray-800' : 'bg-white';
  const muted = dark ? 'text-gray-400' : 'text-gray-600';
  const border = dark ? 'border-gray-700' : 'border-gray-300';
  const input = dark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300 text-gray-900';
  const locked = dark ? 'bg-gray-600 text-gray-300' : 'bg-gray-200 text-gray-600';

  const Field = ({ label, field, type = 'text', options, disabled, checkbox }: FieldConfig) => {
    if (checkbox) return (
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={editData[field] || false} onChange={e => onUpdateField(field, e.target.checked)} className="w-4 h-4 rounded" />
        <span className={muted}>{label}</span>
      </label>
    );
    return (
      <div className="flex flex-col gap-1">
        <label className={`text-xs ${muted} flex items-center gap-1`}>{label} {disabled && <span className="text-blue-400 text-[10px]">({disabledLabel})</span>}</label>
        {type === 'select' ? (
          <select value={editData[field] || ''} onChange={e => onUpdateField(field, e.target.value)} disabled={disabled} className={`text-sm px-2 py-1.5 rounded border ${disabled ? locked : input}`}>
            <option value="">Select...</option>
            {options?.map(o => <option key={o} value={o}>{o}</option>)}
          </select>
        ) : type === 'textarea' ? (
          <textarea value={editData[field] || ''} onChange={e => onUpdateField(field, e.target.value)} disabled={disabled} className={`text-sm px-2 py-1.5 rounded border ${disabled ? locked : input}`} rows={2} />
        ) : (
          <input type={type} value={editData[field] || ''} onChange={e => onUpdateField(field, e.target.value)} disabled={disabled} className={`text-sm px-2 py-1.5 rounded border ${disabled ? locked : input}`} />
        )}
      </div>
    );
  };

  const getFileIcon = (pathOrName: string) => {
    const ext = (pathOrName || '').split('.').pop()?.toLowerCase() || '';
    if (['pdf'].includes(ext)) return '📄';
    if (['doc', 'docx'].includes(ext)) return '📝';
    if (['xls', 'xlsx'].includes(ext)) return '📊';
    if (['stp', 'step', 'igs', 'iges', 'stl'].includes(ext)) return '🔧';
    if (['dwg', 'dxf'].includes(ext)) return '📐';
    if (['jpg', 'jpeg', 'png', 'gif', 'bmp'].includes(ext)) return '🖼️';
    return '📁';
  };

  const openFile = (file: any) => {
    if (file.url) {
      window.open(file.url, '_blank');
    } else if (file.path) {
      window.open('file:///' + file.path.replace(/\\/g, '/'), '_blank');
    }
  };

  const removeFileLink = (id: number) => onUpdateField('fileLinks', (editData.fileLinks || []).filter((f: any) => f.id !== id));
  const updateFileLinkSection = (id: number, section: string) => onUpdateField('fileLinks', (editData.fileLinks || []).map((f: any) => f.id === id ? { ...f, section } : f));

  const removePhoto = (id: number) => onUpdateField('photos', (editData.photos || []).filter((p: any) => p.id !== id));
  const updatePhotoSection = (id: number, section: string) => onUpdateField('photos', (editData.photos || []).map((p: any) => p.id === id ? { ...p, section } : p));

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, _isFolder: boolean) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    const newFiles = files.map((file, idx) => ({
      id: Date.now() + idx,
      path: (file as any).webkitRelativePath || file.name,
      name: file.name,
      section: newFileSection,
      url: URL.createObjectURL(file),
    }));
    onUpdateField('fileLinks', [...(editData.fileLinks || []), ...newFiles]);
    e.target.value = '';
  };

  const addFileLink = () => {
    if (!newFilePath.trim()) return;
    const newFile = { id: Date.now(), path: newFilePath, name: newFilePath.split('\\').pop() || newFilePath.split('/').pop(), section: newFileSection, url: null };
    onUpdateField('fileLinks', [...(editData.fileLinks || []), newFile]);
    setNewFilePath('');
  };

  const addPhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    const isVideo = file.type.startsWith('video/');
    reader.onload = (ev) => {
      const newPhoto = { id: Date.now(), name: file.name, section: newPhotoSection, data: ev.target?.result, isVideo };
      onUpdateField('photos', [...(editData.photos || []), newPhoto]);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const SectionFiles = ({ section }: { section: string }) => {
    const sectionFiles = (editData.fileLinks || []).filter((f: any) => f.section === section);
    if (sectionFiles.length === 0) return null;
    return (
      <div className="mt-3 pt-2 border-t border-dashed border-gray-500">
        <div className={`text-xs ${muted} mb-2`}>Files</div>
        <div className="flex flex-wrap gap-2">
          {sectionFiles.map((file: any) => (
            <div key={file.id} className="relative group">
              <div onClick={() => openFile(file)} className={`h-16 w-20 flex flex-col items-center justify-center rounded border border-gray-500 cursor-pointer hover:opacity-80 transition-opacity ${dark ? 'bg-gray-700' : 'bg-gray-200'}`} title={`Click to open: ${file.name || file.path}`}>
                <span className="text-2xl">{getFileIcon(file.path || file.name)}</span>
                <span className="text-[9px] truncate w-full text-center px-1 mt-1">{file.name || file.path.split('\\').pop() || file.path.split('/').pop()}</span>
              </div>
              <button onClick={() => removeFileLink(file.id)} className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-xs hover:bg-red-600 opacity-0 group-hover:opacity-100 transition-opacity">✕</button>
              <select value={file.section} onChange={e => updateFileLinkSection(file.id, e.target.value)} className={`absolute bottom-0 left-0 right-0 text-xs px-0.5 py-0 rounded-b ${input} opacity-0 group-hover:opacity-100 transition-opacity`}>
                {allSectionNames.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const SectionPhotos = ({ section }: { section: string }) => {
    const sectionPhotos = (editData.photos || []).filter((p: any) => p.section === section);
    if (sectionPhotos.length === 0) return null;
    return (
      <div className="mt-3 pt-2 border-t border-dashed border-gray-500">
        <div className={`text-xs ${muted} mb-2`}>Photos/Videos</div>
        <div className="flex flex-wrap gap-2">
          {sectionPhotos.map((photo: any) => (
            <div key={photo.id} className="relative group">
              {photo.data ? (
                photo.isVideo ? (
                  <div onClick={() => setViewPhoto(photo)} className={`h-16 w-20 flex flex-col items-center justify-center rounded border border-gray-500 cursor-pointer hover:opacity-80 transition-opacity ${dark ? 'bg-gray-700' : 'bg-gray-200'}`} title={`Click to view: ${photo.name}`}>
                    <span className="text-2xl">🎬</span>
                    <span className="text-[8px] truncate w-full text-center px-1">Video</span>
                  </div>
                ) : (
                  <img src={photo.data} alt={photo.name} onClick={() => setViewPhoto(photo)} className="h-16 w-20 object-cover rounded border border-gray-500 cursor-pointer hover:opacity-80 transition-opacity" title={`Click to view: ${photo.name}`} />
                )
              ) : (
                <div className={`h-16 w-20 flex items-center justify-center rounded border border-gray-500 ${dark ? 'bg-gray-700' : 'bg-gray-200'}`} title={photo.name}>
                  <span className="text-xl">🖼️</span>
                </div>
              )}
              <button onClick={() => removePhoto(photo.id)} className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-xs hover:bg-red-600 opacity-0 group-hover:opacity-100 transition-opacity">✕</button>
              <select value={photo.section} onChange={e => updatePhotoSection(photo.id, e.target.value)} className={`absolute bottom-0 left-0 right-0 text-xs px-0.5 py-0 rounded-b ${input} opacity-0 group-hover:opacity-100 transition-opacity`}>
                {allSectionNames.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const allSectionNames = config.sectionNames.length > 0
    ? config.sectionNames
    : config.sections.filter(s => s.hasPhotos || s.hasFiles).map(s => s.title);

  const colSpanMap: Record<number, string> = { 1: 'col-span-1', 2: 'col-span-2', 3: 'col-span-3', 4: 'col-span-4', 5: 'col-span-5', 6: 'col-span-6' };
  const gridColsMap: Record<number, string> = { 1: 'grid-cols-1', 2: 'grid-cols-2', 3: 'grid-cols-3', 4: 'grid-cols-4', 5: 'grid-cols-5', 6: 'grid-cols-6' };

  const renderField = (fieldConfig: FieldConfig) => {
    if (fieldConfig.showWhen && !editData[fieldConfig.showWhen]) return null;

    if (fieldConfig.children) {
      return (
        <div key={fieldConfig.field}>
          <Field {...fieldConfig} />
          {editData[fieldConfig.field] && (
            <div className="ml-6 mt-1 space-y-1">
              {fieldConfig.children.map(child => (
                <Field key={child.field} {...child} />
              ))}
            </div>
          )}
        </div>
      );
    }

    const colClass = fieldConfig.colSpan ? colSpanMap[fieldConfig.colSpan] || '' : '';
    return (
      <div key={fieldConfig.field} className={colClass}>
        <Field {...fieldConfig} />
      </div>
    );
  };

  const renderSection = (section: SectionConfig) => {
    const isListLayout = section.layout === 'list';
    const gridCols = section.gridCols || 3;
    const gridClass = gridColsMap[gridCols] || 'grid-cols-3';

    return (
      <section key={section.title} className={`p-3 rounded-lg border ${border}`}>
        <h3 className={`font-semibold ${section.color} mb-2 border-b ${section.borderColor} pb-1`}>{section.title}</h3>
        <div className={isListLayout ? 'space-y-2' : `grid ${gridClass} gap-3`}>
          {section.fields.map(renderField)}
        </div>
        {section.hasPhotos && <SectionPhotos section={section.title} />}
        {section.hasFiles && <SectionFiles section={section.title} />}
      </section>
    );
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-start justify-center pt-4 z-50 overflow-auto">
      <div className={`${card} rounded-lg p-4 w-full max-w-6xl border ${border} mb-4`}>
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-lg font-bold">Edit Job: {editData[titleField]}</h2>
          <div className="flex gap-2">
            <button onClick={onSave} disabled={saving} className="px-4 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50">{saving ? 'Saving...' : 'Save'}</button>
            <button onClick={onClose} className={`px-4 py-1.5 rounded border ${border}`}>Cancel</button>
          </div>
        </div>

        <div className="space-y-4 text-sm">
          {config.sections.map(renderSection)}

          <div className="grid grid-cols-2 gap-4">
            <section className={`p-3 rounded-lg border ${border}`}>
              <h3 className="font-semibold text-cyan-400 mb-2 border-b border-cyan-400/30 pb-1">Add Files</h3>
              <div className="flex flex-wrap gap-2 items-center">
                <span className={`text-sm ${muted}`}>Section:</span>
                <select value={newFileSection} onChange={e => setNewFileSection(e.target.value)} className={`text-sm px-2 py-1.5 rounded border ${input}`}>
                  {allSectionNames.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
                <label className="px-3 py-1.5 bg-cyan-600 text-white rounded hover:bg-cyan-700 text-sm cursor-pointer">
                  Browse File
                  <input type="file" onChange={e => handleFileSelect(e, false)} className="hidden" />
                </label>
                <label className="px-3 py-1.5 bg-cyan-600 text-white rounded hover:bg-cyan-700 text-sm cursor-pointer">
                  Browse Files
                  <input type="file" multiple onChange={e => handleFileSelect(e, false)} className="hidden" />
                </label>
                <label className="px-3 py-1.5 bg-cyan-600 text-white rounded hover:bg-cyan-700 text-sm cursor-pointer">
                  Browse Folder
                  <input type="file" {...{ webkitdirectory: '' } as any} onChange={e => handleFileSelect(e, true)} className="hidden" />
                </label>
                <span className={`text-xs ${muted}`}>or</span>
                <input type="text" value={newFilePath} onChange={e => setNewFilePath(e.target.value)} placeholder="Enter path manually" className={`flex-1 text-sm px-2 py-1.5 rounded border ${input} min-w-[150px]`} />
                <button onClick={addFileLink} className="px-3 py-1.5 bg-gray-600 text-white rounded hover:bg-gray-700 text-sm">Add Path</button>
              </div>
              <span className={`text-xs ${muted} mt-2 block`}>Files will appear in their assigned section above</span>
            </section>

            <section className={`p-3 rounded-lg border ${border}`}>
              <h3 className="font-semibold text-pink-400 mb-2 border-b border-pink-400/30 pb-1">Add Photos/Videos</h3>
              <div className="flex gap-2 items-center">
                <span className={`text-sm ${muted}`}>Section:</span>
                <select value={newPhotoSection} onChange={e => setNewPhotoSection(e.target.value)} className={`text-sm px-2 py-1.5 rounded border ${input}`}>
                  {allSectionNames.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
                <label className="px-3 py-1.5 bg-pink-600 text-white rounded hover:bg-pink-700 text-sm cursor-pointer">
                  Add Photo/Video
                  <input type="file" accept="image/*,video/*" onChange={addPhoto} className="hidden" />
                </label>
                <span className={`text-xs ${muted} ml-2`}>Photos/Videos will appear in their assigned section above</span>
              </div>
            </section>
          </div>
        </div>

        {viewPhoto && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50" onClick={() => setViewPhoto(null)}>
            <div className="relative max-w-4xl max-h-[90vh] p-2" onClick={e => e.stopPropagation()}>
              <button onClick={() => setViewPhoto(null)} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-8 h-8 text-lg hover:bg-red-600 z-10">✕</button>
              {viewPhoto.isVideo ? (
                <video src={viewPhoto.data} controls className="max-w-full max-h-[85vh] rounded-lg" />
              ) : (
                <img src={viewPhoto.data} alt={viewPhoto.name} className="max-w-full max-h-[85vh] object-contain rounded-lg" />
              )}
              <div className={`text-center mt-2 text-sm ${muted}`}>{viewPhoto.name} — {viewPhoto.section}</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
